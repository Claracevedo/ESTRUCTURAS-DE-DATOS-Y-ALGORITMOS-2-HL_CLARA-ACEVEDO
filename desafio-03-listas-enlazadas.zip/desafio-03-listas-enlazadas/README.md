# Desafío 03 — Listas enlazadas y doblemente enlazadas

**Estructuras de Datos II** · Universidad Autónoma de Occidente
Clase 03 — Listas · Profesor Jonathan López Londoño

Aplicación en React con dos páginas que usan estructuras de listas implementadas a mano,
sin librerías de estructuras de datos.

---

## Qué resuelve del enunciado

| Punto del desafío | Dónde está resuelto |
|---|---|
| Lista enlazada para reproducir canciones en orden, con datos simulados | `src/structures/LinkedList.js` + `src/data/canciones.js` |
| Lista doblemente enlazada para navegar adelante y atrás entre páginas visitadas, con datos ficticios | `src/structures/DoublyLinkedList.js` + `src/data/paginas.js` |
| Proyecto React con 2 páginas nuevas | `src/pages/Reproductor.jsx` y `src/pages/Historial.jsx`, enrutadas en `src/App.jsx` |
| Usar cada lista en su página y recorrerla con botones dentro de la página | Botones **Siguiente / Volver al inicio** (página 1) y **◂ Atrás / Adelante ▸** (página 2) |

---

## Cómo ejecutarlo

Requiere Node.js 18 o superior.

```bash
npm install
npm run dev
```

Abrir la URL que imprime Vite (por defecto `http://localhost:5173`).

Para generar la versión de producción:

```bash
npm run build
npm run preview
```

---

## Estructura del proyecto

```
desafio-03-listas-enlazadas/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                    # punto de entrada + HashRouter
    ├── App.jsx                     # layout y rutas de las 2 páginas
    ├── index.css                   # estilos (tema claro y oscuro)
    ├── structures/
    │   ├── LinkedList.js           # Node + LinkedList  (simple)
    │   └── DoublyLinkedList.js     # DoublyNode + DoublyLinkedList
    ├── data/
    │   ├── canciones.js            # datos simulados de la playlist
    │   └── paginas.js              # datos ficticios del historial
    ├── components/
    │   ├── Cadena.jsx              # dibuja los nodos y sus punteros
    │   ├── Estado.jsx              # head, tail, size(), punteros del nodo actual
    │   ├── Consola.jsx             # registro de cada llamada a los métodos
    │   └── Codigo.jsx              # muestra el código fuente real de las clases
    └── pages/
        ├── Reproductor.jsx         # PÁGINA 1 — lista enlazada simple
        └── Historial.jsx           # PÁGINA 2 — lista doblemente enlazada
```

---

## Página 1 — Reproductor de canciones (lista enlazada simple)

La lista se llena con `append()` a partir de 5 canciones simuladas. Cada nodo guarda
la canción y **un solo puntero**, `next`.

| Botón | Operación |
|---|---|
| Siguiente | `nodoActual.next` — avanza un nodo |
| Volver al inicio | `this.head` — no existe `prev`, hay que saltar a la cabeza |
| Agregar canción | `append(valor)` |
| Quitar de la lista | `remove(id)` — une el nodo anterior con el siguiente |
| Imprimir | `print()` — `a -> b -> c -> null` |

Métodos implementados en `LinkedList`: `append`, `peek`, `size`, `remove`, `print`, `toArray`.

## Página 2 — Historial del navegador (lista doblemente enlazada)

La lista se llena con `append()` a partir de 5 URLs ficticias. Cada nodo guarda
**dos punteros**, `prev` y `next`, así que ir atrás cuesta un solo salto.

| Botón | Operación |
|---|---|
| ◂ Atrás | `nodoActual.prev` |
| Adelante ▸ | `nodoActual.next` |
| Visitar página nueva | `append(valor)` y salto al nuevo `tail` |
| Borrar del historial | `remove(id)` — reconecta `prev` y `next` |
| Imprimir | `print()` — `null <-> a <-> b <-> null` |
| Imprimir al revés | `printReverse()` — recorre desde `tail` usando `prev` |

Métodos implementados en `DoublyLinkedList`: `append`, `peek`, `size`, `remove`,
`print`, `printReverse`, `toArray`.

---

## Notas de implementación

- Las listas se guardan en un `useRef`, no en `useState`: son estructuras **mutables**,
  y el estado de React se usa solo para el nodo actual y para forzar el re-render
  después de `append` / `remove`.
- El panel «Implementación» de cada página muestra el **código fuente real** del
  archivo, importado con el sufijo `?raw` de Vite. No es una copia pegada.
- La interfaz se adapta al tema claro u oscuro del sistema y funciona en móvil.
- `HashRouter` en lugar de `BrowserRouter` para que el build funcione también al
  abrirlo como archivo o al publicarlo en GitHub Pages.

---

## Publicar en GitHub

```bash
git init
git add .
git commit -m "Desafío 03 — listas enlazadas y doblemente enlazadas en React"
git branch -M main
git remote add origin https://github.com/USUARIO/desafio-03-listas-enlazadas.git
git push -u origin main
```

`node_modules/` y `dist/` están excluidos en `.gitignore`.
