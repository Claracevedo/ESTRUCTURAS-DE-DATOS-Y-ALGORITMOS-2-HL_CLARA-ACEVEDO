import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Base relativa para que el build funcione también en GitHub Pages.
export default defineConfig({
  plugins: [react()],
  base: "./",
});
