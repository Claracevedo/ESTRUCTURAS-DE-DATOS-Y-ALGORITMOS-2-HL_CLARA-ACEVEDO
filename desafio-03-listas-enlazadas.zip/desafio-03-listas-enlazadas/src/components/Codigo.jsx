import { useState } from "react";

/**
 * Panel con pestañas que muestra el código fuente real de los archivos
 * (se importan con el sufijo ?raw de Vite, no son copias).
 */
export default function Codigo({ fuentes }) {
  const [tab, setTab] = useState(0);

  return (
    <section className="panel">
      <header>
        <span>Implementación</span>
        <div className="tabs" role="tablist">
          {fuentes.map((f, i) => (
            <button
              key={f.nombre}
              role="tab"
              aria-selected={i === tab}
              onClick={() => setTab(i)}
            >
              {f.nombre}
            </button>
          ))}
        </div>
      </header>
      <pre>
        <code>{fuentes[tab].codigo}</code>
      </pre>
    </section>
  );
}
