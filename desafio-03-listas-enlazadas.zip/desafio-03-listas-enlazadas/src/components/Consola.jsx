/** Muestra cada llamada a los métodos de la lista y su resultado. */
export default function Consola({ log }) {
  return (
    <section className="panel">
      <header>
        <span>Consola · print()</span>
        <span>{log.length} operaciones</span>
      </header>
      <div className="console">
        {log.map((l, i) => (
          <div className="line" key={log.length - i}>
            <span className="n">{String(log.length - i).padStart(2, "0")}</span>
            <span className="call">{l.call}</span>
            <span className="res">{l.res}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
