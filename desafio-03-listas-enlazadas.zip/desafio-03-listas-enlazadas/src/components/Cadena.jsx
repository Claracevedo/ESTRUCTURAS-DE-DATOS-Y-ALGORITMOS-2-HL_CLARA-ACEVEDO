import { useEffect, useRef } from "react";

/**
 * Dibuja la cadena de nodos con sus punteros.
 * - doble = false → solo flecha next
 * - doble = true  → flechas next y prev, y null en los dos extremos
 */
export default function Cadena({ items, currentId, doble = false, render }) {
  const actualRef = useRef(null);
  const scrollRef = useRef(null);

  // Mantiene el nodo actual visible dentro del contenedor con scroll.
  useEffect(() => {
    const el = actualRef.current;
    const box = scrollRef.current;
    if (!el || !box) return;

    const suave = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const destino = el.offsetLeft - (box.clientWidth - el.offsetWidth) / 2;

    box.scrollTo({ left: Math.max(0, destino), behavior: suave ? "smooth" : "auto" });
  }, [currentId, items.length]);

  if (items.length === 0) {
    return (
      <div className="chain-scroll">
        <div className="emptychain">head = null · la lista está vacía</div>
      </div>
    );
  }

  const piezas = [];

  if (doble) piezas.push(<span className="nullcap" key="n0">null</span>);

  items.forEach((item, i) => {
    if (i > 0) {
      const activo = items[i - 1].id === currentId || item.id === currentId;
      piezas.push(
        <div className={"link" + (activo ? " active" : "")} key={"l" + item.id}>
          <div className="arrow">
            <i></i>
            <span>next ▸</span>
          </div>
          {doble && (
            <div className="arrow">
              <span>◂ prev</span>
              <i></i>
            </div>
          )}
        </div>
      );
    }

    piezas.push(
      <div
        className={"node" + (item.id === currentId ? " current" : "")}
        key={item.id}
        ref={item.id === currentId ? actualRef : null}
      >
        <div className="idx">[{i}]</div>
        {render(item)}
        <div className="badges">
          {i === 0 && <span className="badge head">head</span>}
          {i === items.length - 1 && <span className="badge tail">tail</span>}
        </div>
      </div>
    );
  });

  piezas.push(
    <span className="nullcap" key="nz">
      {doble ? "null" : "→ null"}
    </span>
  );

  return (
    <div className="chain-scroll" ref={scrollRef}>
      <div className="chain">{piezas}</div>
    </div>
  );
}
