/** Estado en vivo de la lista: head, tail, size() y punteros del nodo actual. */
export default function Estado({ filas }) {
  return (
    <section className="panel">
      <header>
        <span>Estado de la lista</span>
      </header>
      <div className="state">
        <dl>
          {filas.map((f) => (
            <div className="row" key={f.k}>
              <dt>{f.k}</dt>
              <dd className={f.v === "null" ? "nil" : ""}>{f.v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
