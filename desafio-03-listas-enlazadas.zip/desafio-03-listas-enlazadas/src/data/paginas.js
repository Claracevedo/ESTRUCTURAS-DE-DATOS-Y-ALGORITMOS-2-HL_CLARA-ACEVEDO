// Datos ficticios para la lista doblemente enlazada (historial del navegador).

export const VISITADAS = [
  { id: "p1", url: "uao.edu.co/inicio", titulo: "Universidad Autónoma de Occidente" },
  { id: "p2", url: "uao.edu.co/ing-sistemas/estructuras-2", titulo: "Estructuras de Datos II" },
  { id: "p3", url: "campus.uao.edu.co/desafio-03", titulo: "Desafío 03 — Listas enlazadas" },
  { id: "p4", url: "react.dev/learn/state-a-components-memory", titulo: "State: A Component's Memory" },
  { id: "p5", url: "github.com/jac/desafio-03-listas", titulo: "jac/desafio-03-listas" },
];

// Páginas que se agregan con el botón append().
export const COLA_VISITADAS = [
  { id: "p6", url: "developer.mozilla.org/es/docs/Web/API/History", titulo: "History API — MDN" },
  { id: "p7", url: "vitejs.dev/guide", titulo: "Vite — Guía de inicio" },
  { id: "p8", url: "es.wikipedia.org/wiki/Lista_doblemente_enlazada", titulo: "Lista doblemente enlazada" },
];
