// Datos simulados para la lista enlazada simple (reproductor).

export const CANCIONES = [
  { id: "s1", titulo: "La Rebelión", artista: "Joe Arroyo", dur: "5:32" },
  { id: "s2", titulo: "Cali Pachanguero", artista: "Grupo Niche", dur: "6:04" },
  { id: "s3", titulo: "Oye Cómo Va", artista: "Tito Puente", dur: "4:17" },
  { id: "s4", titulo: "Pedro Navaja", artista: "Rubén Blades", dur: "7:21" },
  { id: "s5", titulo: "El Preso", artista: "Fruko y sus Tesos", dur: "4:46" },
];

// Canciones que se agregan con el botón append().
export const COLA_CANCIONES = [
  { id: "s6", titulo: "Las Caleñas", artista: "The Latin Brothers", dur: "5:12" },
  { id: "s7", titulo: "Micaela", artista: "Sonora Carruseles", dur: "4:58" },
  { id: "s8", titulo: "Cómo Te Voy a Olvidar", artista: "Los Ángeles Azules", dur: "3:49" },
];
