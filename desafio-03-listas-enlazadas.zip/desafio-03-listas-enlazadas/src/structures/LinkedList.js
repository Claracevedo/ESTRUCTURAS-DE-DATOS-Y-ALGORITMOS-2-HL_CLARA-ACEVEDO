/**
 * Lista enlazada simple.
 * Estructuras de Datos II — Clase 03, Desafío 03.
 *
 * Cada nodo guarda un valor y UN solo puntero (next), por eso la lista
 * únicamente puede recorrerse hacia adelante.
 */

export class Node {
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

export class LinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  /** Agrega un nodo al final de la lista. */
  append(value) {
    const node = new Node(value);

    if (!this.head) {
      this.head = node;
      this.tail = node;
    } else {
      this.tail.next = node;
      this.tail = node;
    }

    this.length++;
    return node;
  }

  /** Devuelve el nodo cuyo value.id coincide (búsqueda recursiva). */
  peek(value, current = this.head) {
    if (!current) return null;
    if (current.value.id === value) return current;
    return this.peek(value, current.next);
  }

  /** Número de elementos de la lista. */
  size() {
    return this.length;
  }

  /** Elimina un nodo y une el anterior con el siguiente. */
  remove(value, current = this.head) {
    if (!this.head) return null;

    // Caso 1: el nodo a eliminar es la cabeza.
    if (this.head.value.id === value) {
      const out = this.head;
      this.head = this.head.next;
      if (!this.head) this.tail = null;
      this.length--;
      return out;
    }

    // Caso 2: se avanza hasta el nodo anterior al buscado.
    while (current.next && current.next.value.id !== value) {
      current = current.next;
    }

    if (current.next) {
      const out = current.next;
      current.next = current.next.next;
      if (!current.next) this.tail = current;
      this.length--;
      return out;
    }

    return null;
  }

  /** Representación textual de la lista: a -> b -> c -> null */
  print(campo = "titulo") {
    const out = [];
    let current = this.head;

    while (current) {
      out.push(current.value[campo]);
      current = current.next;
    }

    return out.join(" -> ") + " -> null";
  }

  /** Utilidad para renderizar la lista en React. */
  toArray() {
    const out = [];
    let current = this.head;

    while (current) {
      out.push(current.value);
      current = current.next;
    }

    return out;
  }
}
