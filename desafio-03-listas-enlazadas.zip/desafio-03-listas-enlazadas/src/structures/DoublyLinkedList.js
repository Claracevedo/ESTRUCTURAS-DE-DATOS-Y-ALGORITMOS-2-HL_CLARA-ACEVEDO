/**
 * Lista doblemente enlazada.
 * Estructuras de Datos II — Clase 03, Desafío 03.
 *
 * Cada nodo guarda DOS punteros (prev y next), así que la lista puede
 * recorrerse hacia adelante y hacia atrás en un solo paso.
 */

export class DoublyNode {
  constructor(value, next = null, prev = null) {
    this.value = value;
    this.next = next;
    this.prev = prev; // ← lo que añade la lista doble
  }
}

export class DoublyLinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  /** Agrega un nodo al final, enlazándolo en los dos sentidos. */
  append(value) {
    const node = new DoublyNode(value);

    if (!this.head) {
      this.head = node;
      this.tail = node;
    } else {
      node.prev = this.tail; // enlace hacia atrás
      this.tail.next = node; // enlace hacia adelante
      this.tail = node;
    }

    this.length++;
    return node;
  }

  /** Devuelve el nodo cuyo value.id coincide (búsqueda recursiva). */
  peek(value, current = this.head) {
    if (!current) return null;
    if (current.value.id === value) return current;
    return this.peek(value, current.next);
  }

  /** Número de elementos de la lista. */
  size() {
    return this.length;
  }

  /** Elimina un nodo y reconecta su prev con su next. */
  remove(value) {
    if (!this.head) return null;

    let current = this.head;

    while (current) {
      if (current.value.id === value) {
        if (current === this.head) {
          this.head = current.next;
          if (this.head) this.head.prev = null;
        }

        if (current === this.tail) {
          this.tail = current.prev;
          if (this.tail) this.tail.next = null;
        }

        if (current.prev) current.prev.next = current.next;
        if (current.next) current.next.prev = current.prev;

        this.length--;
        return current;
      }

      current = current.next;
    }

    return null;
  }

  /** Representación textual: null <-> a <-> b <-> null */
  print(campo = "url") {
    const out = [];
    let current = this.head;

    while (current) {
      out.push(current.value[campo]);
      current = current.next;
    }

    return "null <-> " + out.join(" <-> ") + " <-> null";
  }

  /** Recorrido inverso, aprovechando prev desde la cola. */
  printReverse(campo = "url") {
    const out = [];
    let current = this.tail;

    while (current) {
      out.push(current.value[campo]);
      current = current.prev;
    }

    return "null <-> " + out.join(" <-> ") + " <-> null";
  }

  /** Utilidad para renderizar la lista en React. */
  toArray() {
    const out = [];
    let current = this.head;

    while (current) {
      out.push(current.value);
      current = current.next;
    }

    return out;
  }
}
