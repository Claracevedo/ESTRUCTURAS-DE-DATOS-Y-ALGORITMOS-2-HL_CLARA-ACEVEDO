import { NavLink, Route, Routes, Navigate } from "react-router-dom";
import Reproductor from "./pages/Reproductor";
import Historial from "./pages/Historial";

const RUTAS = [
  {
    to: "/reproductor",
    num: "Página 1",
    nombre: "Reproductor de canciones",
    kind: "lista simple",
    tono: { "--accent": "var(--simple)", "--accent-wash": "var(--simple-w)" },
  },
  {
    to: "/historial",
    num: "Página 2",
    nombre: "Historial del navegador",
    kind: "lista doble",
    tono: { "--accent": "var(--doble)", "--accent-wash": "var(--doble-w)" },
  },
];

export default function App() {
  return (
    <div className="wrap">
      <header className="masthead">
        <div>
          <p className="eyebrow">Desafío 03 · Diapositiva 18</p>
          <h1>Listas enlazadas en React</h1>
        </div>
        <div className="course">
          <b>Estructuras de Datos II</b>
          <br />
          Universidad Autónoma de Occidente
          <br />
          Clase 03 — Listas
        </div>
      </header>

      <nav className="pages">
        {RUTAS.map((r) => (
          <NavLink key={r.to} to={r.to} style={r.tono}>
            <span className="num">{r.num}</span>
            {r.nombre}
            <span className="kind">{r.kind}</span>
          </NavLink>
        ))}
      </nav>

      <Routes>
        <Route path="/" element={<Navigate to="/reproductor" replace />} />
        <Route path="/reproductor" element={<Reproductor />} />
        <Route path="/historial" element={<Historial />} />
        <Route path="*" element={<Navigate to="/reproductor" replace />} />
      </Routes>

      <footer className="credits">
        <span>Estructuras de Datos II · Jonathan López Londoño</span>
        <span>React 18 · listas implementadas a mano, sin librerías</span>
      </footer>
    </div>
  );
}
