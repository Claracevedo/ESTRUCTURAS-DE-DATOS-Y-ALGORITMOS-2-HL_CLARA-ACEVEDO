import { useState, useRef, useCallback } from "react";
import { LinkedList } from "../structures/LinkedList";
import { CANCIONES, COLA_CANCIONES } from "../data/canciones";
import Cadena from "../components/Cadena";
import Consola from "../components/Consola";
import Estado from "../components/Estado";
import Codigo from "../components/Codigo";

// Vite entrega el código fuente real de estos archivos como texto.
import fuenteLista from "../structures/LinkedList.js?raw";
import fuentePagina from "./Reproductor.jsx?raw";

/**
 * PÁGINA 1 — Reproductor de canciones.
 * Usa una LISTA ENLAZADA SIMPLE: solo se puede avanzar con nodo.next.
 */
export default function Reproductor() {
  // La lista vive en un ref porque es una estructura mutable, no estado de React.
  const lista = useRef(null);
  if (!lista.current) {
    lista.current = new LinkedList();
    CANCIONES.forEach((c) => lista.current.append(c));
  }

  const porAgregar = useRef(0);
  const [actualId, setActualId] = useState(CANCIONES[0].id);
  const [, forzar] = useState(0); // fuerza el re-render tras mutar la lista
  const [log, setLog] = useState([
    { call: "print()", res: lista.current.print("titulo") },
    { call: "append() ×5", res: "lista inicializada con datos simulados" },
  ]);

  const anotar = useCallback((call, res) => {
    setLog((l) => [{ call, res }, ...l].slice(0, 40));
  }, []);

  const items = lista.current.toArray();
  const nodoActual = lista.current.peek(actualId);

  // Avanzar: el único movimiento posible en una lista simple.
  const siguiente = () => {
    if (!nodoActual || !nodoActual.next) return;
    const n = nodoActual.next;
    setActualId(n.value.id);
    anotar("nodo.next", "▸ " + n.value.titulo + " · " + n.value.artista);
  };

  // Sin prev, volver atrás obliga a saltar a head y recorrer de nuevo.
  const reiniciar = () => {
    if (!lista.current.head) return;
    setActualId(lista.current.head.value.id);
    anotar("this.head", "◂ vuelta al inicio: " + lista.current.head.value.titulo);
  };

  const agregar = () => {
    const c = COLA_CANCIONES[porAgregar.current % COLA_CANCIONES.length];
    const copia = { ...c, id: c.id + "-" + porAgregar.current };
    porAgregar.current++;

    lista.current.append(copia);
    if (!actualId || !lista.current.peek(actualId)) setActualId(copia.id);
    forzar((v) => v + 1);
    anotar(
      "append(" + copia.titulo + ")",
      "tail ahora es «" + copia.titulo + "» · length = " + lista.current.size()
    );
  };

  const quitar = () => {
    if (!nodoActual) return;
    const sig = nodoActual.next;
    const out = lista.current.remove(actualId);
    const destino = sig || lista.current.head;

    setActualId(destino ? destino.value.id : null);
    forzar((v) => v + 1);
    anotar(
      "remove(" + out.value.titulo + ")",
      "nodo eliminado · length = " + lista.current.size()
    );
  };

  const imprimir = () => anotar("print()", lista.current.print("titulo"));

  return (
    <div className="page" data-list="simple">
      <p className="lede">
        Una <strong>lista enlazada simple</strong> reproduce la playlist <strong>en orden</strong>:
        cada nodo guarda la canción y un único puntero <code>next</code>. Por eso el reproductor
        solo puede avanzar — para volver al principio hay que saltar a <code>head</code> y recorrer
        de nuevo.
      </p>

      <section className="panel">
        <div className="focus">
          <span className="tag">Reproduciendo ahora</span>
          <p className="primary">{nodoActual ? nodoActual.value.titulo : "—"}</p>
          <span className="secondary">
            {nodoActual ? nodoActual.value.artista + " · " + nodoActual.value.dur : "lista vacía"}
          </span>
        </div>

        <Cadena
          items={items}
          currentId={actualId}
          doble={false}
          render={(c) => (
            <>
              <div className="val">{c.titulo}</div>
              <div className="meta">
                {c.artista}
                <br />
                {c.dur}
              </div>
            </>
          )}
        />

        <div className="controls">
          <button
            className="btn primary"
            onClick={siguiente}
            disabled={!nodoActual || !nodoActual.next}
          >
            Siguiente <span className="k">nodo.next</span>
          </button>
          <button className="btn" onClick={reiniciar} disabled={!lista.current.head}>
            Volver al inicio <span className="k">this.head</span>
          </button>
          <button className="btn" onClick={agregar}>
            Agregar canción <span className="k">append()</span>
          </button>
          <button className="btn" onClick={quitar} disabled={!nodoActual}>
            Quitar de la lista <span className="k">remove()</span>
          </button>
          <button className="btn" onClick={imprimir}>
            Imprimir <span className="k">print()</span>
          </button>
        </div>
      </section>

      <div className="split">
        <Estado
          filas={[
            { k: "head", v: lista.current.head ? lista.current.head.value.titulo : "null" },
            { k: "tail", v: lista.current.tail ? lista.current.tail.value.titulo : "null" },
            { k: "size()", v: String(lista.current.size()) },
            {
              k: "nodo.next",
              v: nodoActual && nodoActual.next ? nodoActual.next.value.titulo : "null",
            },
          ]}
        />
        <Consola log={log} />
      </div>

      <Codigo
        fuentes={[
          { nombre: "LinkedList.js", codigo: fuenteLista },
          { nombre: "Reproductor.jsx", codigo: fuentePagina },
        ]}
      />
    </div>
  );
}
