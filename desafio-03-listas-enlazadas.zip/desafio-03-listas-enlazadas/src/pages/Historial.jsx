import { useState, useRef, useCallback } from "react";
import { DoublyLinkedList } from "../structures/DoublyLinkedList";
import { VISITADAS, COLA_VISITADAS } from "../data/paginas";
import Cadena from "../components/Cadena";
import Consola from "../components/Consola";
import Estado from "../components/Estado";
import Codigo from "../components/Codigo";

// Vite entrega el código fuente real de estos archivos como texto.
import fuenteLista from "../structures/DoublyLinkedList.js?raw";
import fuentePagina from "./Historial.jsx?raw";

/**
 * PÁGINA 2 — Historial del navegador.
 * Usa una LISTA DOBLEMENTE ENLAZADA: se navega con nodo.prev y nodo.next.
 */
export default function Historial() {
  const historial = useRef(null);
  if (!historial.current) {
    historial.current = new DoublyLinkedList();
    VISITADAS.forEach((p) => historial.current.append(p));
  }

  const porVisitar = useRef(0);
  const [actualId, setActualId] = useState(VISITADAS[VISITADAS.length - 1].id);
  const [, forzar] = useState(0);
  const [log, setLog] = useState([
    { call: "print()", res: historial.current.print("url") },
    { call: "append() ×5", res: "historial inicializado con datos ficticios" },
  ]);

  const anotar = useCallback((call, res) => {
    setLog((l) => [{ call, res }, ...l].slice(0, 40));
  }, []);

  const items = historial.current.toArray();
  const nodoActual = historial.current.peek(actualId);

  // Atrás: un solo salto gracias al puntero prev.
  const atras = () => {
    if (!nodoActual || !nodoActual.prev) return;
    const n = nodoActual.prev;
    setActualId(n.value.id);
    anotar("nodo.prev", "◂ " + n.value.url);
  };

  // Adelante: un solo salto gracias al puntero next.
  const adelante = () => {
    if (!nodoActual || !nodoActual.next) return;
    const n = nodoActual.next;
    setActualId(n.value.id);
    anotar("nodo.next", "▸ " + n.value.url);
  };

  const visitar = () => {
    const p = COLA_VISITADAS[porVisitar.current % COLA_VISITADAS.length];
    const copia = { ...p, id: p.id + "-" + porVisitar.current };
    porVisitar.current++;

    historial.current.append(copia);
    setActualId(copia.id);
    forzar((v) => v + 1);
    anotar(
      "append(" + copia.url + ")",
      "nuevo tail · length = " + historial.current.size()
    );
  };

  const olvidar = () => {
    if (!nodoActual) return;
    const destino = nodoActual.prev || nodoActual.next;
    const out = historial.current.remove(actualId);

    setActualId(destino ? destino.value.id : null);
    forzar((v) => v + 1);
    anotar(
      "remove(" + out.value.url + ")",
      "prev y next reconectados · length = " + historial.current.size()
    );
  };

  const imprimir = () => anotar("print()", historial.current.print("url"));
  const imprimirInverso = () =>
    anotar("printReverse()", historial.current.printReverse("url"));

  return (
    <div className="page" data-list="doble">
      <p className="lede">
        El historial del navegador necesita ir <strong>hacia adelante y hacia atrás</strong>, así
        que cada nodo guarda dos punteros: <code>next</code> y <code>prev</code>. «Atrás» no recorre
        la lista: salta directamente a <code>nodo.prev</code> en un solo paso.
      </p>

      <section className="panel">
        <div className="focus">
          <span className="tag">Página actual</span>
          <p className="primary">{nodoActual ? nodoActual.value.titulo : "—"}</p>
          <span className="secondary">
            {nodoActual ? nodoActual.value.url : "historial vacío"}
          </span>
        </div>

        <Cadena
          items={items}
          currentId={actualId}
          doble={true}
          render={(p) => (
            <>
              <div className="val">{p.titulo}</div>
              <div className="meta">{p.url}</div>
            </>
          )}
        />

        <div className="controls">
          <button className="btn" onClick={atras} disabled={!nodoActual || !nodoActual.prev}>
            ◂ Atrás <span className="k">nodo.prev</span>
          </button>
          <button
            className="btn primary"
            onClick={adelante}
            disabled={!nodoActual || !nodoActual.next}
          >
            Adelante ▸ <span className="k">nodo.next</span>
          </button>
          <button className="btn" onClick={visitar}>
            Visitar página nueva <span className="k">append()</span>
          </button>
          <button className="btn" onClick={olvidar} disabled={!nodoActual}>
            Borrar del historial <span className="k">remove()</span>
          </button>
          <button className="btn" onClick={imprimir}>
            Imprimir <span className="k">print()</span>
          </button>
          <button className="btn" onClick={imprimirInverso}>
            Imprimir al revés <span className="k">printReverse()</span>
          </button>
        </div>
      </section>

      <div className="split">
        <Estado
          filas={[
            { k: "head", v: historial.current.head ? historial.current.head.value.url : "null" },
            { k: "tail", v: historial.current.tail ? historial.current.tail.value.url : "null" },
            { k: "size()", v: String(historial.current.size()) },
            {
              k: "nodo.prev",
              v: nodoActual && nodoActual.prev ? nodoActual.prev.value.url : "null",
            },
            {
              k: "nodo.next",
              v: nodoActual && nodoActual.next ? nodoActual.next.value.url : "null",
            },
          ]}
        />
        <Consola log={log} />
      </div>

      <Codigo
        fuentes={[
          { nombre: "DoublyLinkedList.js", codigo: fuenteLista },
          { nombre: "Historial.jsx", codigo: fuentePagina },
        ]}
      />
    </div>
  );
}
